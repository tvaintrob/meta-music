
class LastFMError(Exception):
    pass
